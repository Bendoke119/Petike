﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Konyv
{
    public string Cim { get; set; }
    public string Iro { get; set; }
    public string Zsaner { get; set; }
    public int Ar { get; set; }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        List<Konyv> konyvek = new List<Konyv>();
        string[] sorok = File.ReadAllLines("konyvek.txt", Encoding.UTF8);

        foreach (string sor in sorok)
        {
            if (string.IsNullOrWhiteSpace(sor)) continue;

            string[] reszek = sor.Split(';');
            Konyv ujKonyv = new Konyv();
            ujKonyv.Cim = reszek[0].Trim();
            ujKonyv.Iro = reszek[1].Trim();
            ujKonyv.Zsaner = reszek[2].Trim();
            ujKonyv.Ar = int.Parse(reszek[3].Trim());
            konyvek.Add(ujKonyv);
        }

        foreach (Konyv k in konyvek)
        {
            Console.WriteLine($"{k.Cim} | {k.Iro} | {k.Zsaner} | {k.Ar} Ft");
        }

        Konyv legdragabb = konyvek[0];
        foreach (Konyv k in konyvek)
        {
            if (k.Ar > legdragabb.Ar)
                legdragabb = k;
        }
        Console.WriteLine($"{legdragabb.Cim} ({legdragabb.Ar} Ft)");

        Konyv legolcsobb = konyvek[0];
        foreach (Konyv k in konyvek)
        {
            if (k.Ar < legolcsobb.Ar)
                legolcsobb = k;
        }
        Console.WriteLine($"{legolcsobb.Cim} ({legolcsobb.Ar} Ft)");

        int osszar = 0;
        foreach (Konyv k in konyvek)
        {
            osszar += k.Ar;
        }
        Console.WriteLine($"{osszar} Ft");

        string keresettZsaner = "Regény";
        foreach (Konyv k in konyvek)
        {
            if (k.Zsaner == keresettZsaner)
            {
                Console.WriteLine($"{k.Cim} ({k.Iro})");
            }
        }
    }
}