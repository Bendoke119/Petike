﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Könyv
{
    public string Cím { get; set; }
    public string Író { get; set; }
    public string Zsáner { get; set; }
    public int Ár { get; set; }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        List<Könyv> könyvek = new List<Könyv>();
        string[] sorok = File.ReadAllLines("konyvek.txt", Encoding.UTF8);

        foreach (string sor in sorok)
        {
            if (string.IsNullOrWhiteSpace(sor)) continue;

            string[] részek = sor.Split(';');
            Könyv újKönyv = new Könyv();
            újKönyv.Cím = részek[0].Trim();
            újKönyv.Író = részek[1].Trim();
            újKönyv.Zsáner = részek[2].Trim();
            újKönyv.Ár = int.Parse(részek[3].Trim());
            könyvek.Add(újKönyv);
        }

        Console.WriteLine("A könyvesbolt kínálata:");
        foreach (Könyv k in könyvek)
        {
            Console.WriteLine($"- {k.Cím} | Író: {k.Író} | Zsáner: {k.Zsáner} | Ár: {k.Ár} Ft");
        }

        Könyv legdrágább = könyvek[0];
        foreach (Könyv k in könyvek)
        {
            if (k.Ár > legdrágább.Ár)
                legdrágább = k;
        }
        Console.WriteLine($"\nLegdrágább könyv: {legdrágább.Cím} ({legdrágább.Ár} Ft)");

        Könyv legolcsóbb = könyvek[0];
        foreach (Könyv k in könyvek)
        {
            if (k.Ár < legolcsóbb.Ár)
                legolcsóbb = k;
        }
        Console.WriteLine($"Legolcsóbb könyv: {legolcsóbb.Cím} ({legolcsóbb.Ár} Ft)");

        int összár = 0;
        foreach (Könyv k in könyvek)
        {
            összár += k.Ár;
        }
        Console.WriteLine($"Könyvek összára: {összár} Ft");

        string keresettZsáner = "Regény";
        Console.WriteLine($"{keresettZsáner} zsánerű könyvek:");
        foreach (Könyv k in könyvek)
        {
            if (k.Zsáner == keresettZsáner)
            {
                Console.WriteLine($"- {k.Cím} ({k.Író})");
            }
        }
    }
}